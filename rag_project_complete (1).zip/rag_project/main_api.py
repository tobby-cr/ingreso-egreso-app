import uvicorn
from core.config import get_settings
settings = get_settings()
if __name__ == "__main__":
    uvicorn.run("interfaces.api.main:app", host=settings.api_host, port=settings.api_port, reload=settings.api_reload)
