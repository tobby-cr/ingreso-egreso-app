# RAG Project - Enhanced

Local-first RAG baseline.
