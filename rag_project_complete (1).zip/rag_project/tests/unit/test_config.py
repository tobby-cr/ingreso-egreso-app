from core.config import get_settings

def test_settings():
    s = get_settings()
    assert s is not None
