import streamlit as st
from core.config import get_settings
from core.embedding_system import EnhancedAsyncEmbeddingSystem
from core.engine import ApplicationEngine, ApplicationConfig
from pathlib import Path
import asyncio

st.set_page_config(page_title='RAG Local', layout='wide')

@st.cache_resource
def get_engine():
    settings = get_settings()
    emb = EnhancedAsyncEmbeddingSystem(config=settings)
    asyncio.run(emb._initialize())
    cfg = ApplicationConfig(allowed_upload_dir=str(Path(settings.storage_path) / 'uploads'), max_file_size_bytes=settings.max_file_size_mb*1024*1024)
    engine = ApplicationEngine(embedding_system=emb, config=cfg)
    asyncio.run(engine.initialize())
    return engine

engine = get_engine()

st.title("RAG Local")
tab1, tab2 = st.tabs(["Upload", "Query"])
with tab1:
    uploaded = st.file_uploader("Upload", accept_multiple_files=False)
    if uploaded and st.button("Process"):
        tmp = "/tmp/" + uploaded.name
        with open(tmp, "wb") as fh:
            fh.write(uploaded.getbuffer())
        res = asyncio.run(engine.process_upload(tmp))
        st.write(res)
with tab2:
    q = st.text_input("Question")
    if q and st.button("Ask"):
        res = asyncio.run(engine.process_query(q))
        st.write(res)
