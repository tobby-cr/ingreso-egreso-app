import asyncio
from pathlib import Path
from core.config import get_settings
from core.embedding_system import EnhancedAsyncEmbeddingSystem
from core.engine import ApplicationEngine, ApplicationConfig

async def main():
    settings = get_settings()
    emb = EnhancedAsyncEmbeddingSystem(config=settings)
    await emb._initialize()
    engine_cfg = ApplicationConfig(allowed_upload_dir=str(Path(settings.storage_path) / "uploads"), max_file_size_bytes=settings.max_file_size_mb*1024*1024)
    engine = ApplicationEngine(embedding_system=emb, config=engine_cfg)
    await engine.initialize()
    print("CLI ready. Use 'upload <path>' or 'query <question>'")
    while True:
        cmd = input(">>> ").strip()
        if cmd in ("exit","quit"):
            break
        if cmd.startswith("upload "):
            path = cmd.split(" ",1)[1].strip()
            res = await engine.process_upload(path)
            print(res)
        elif cmd.startswith("query "):
            q = cmd.split(" ",1)[1].strip()
            res = await engine.process_query(q)
            print(res)
        else:
            print("unknown command")

if __name__=='__main__':
    asyncio.run(main())
