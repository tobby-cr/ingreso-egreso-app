from datetime import datetime, timedelta
from typing import Dict, Any
from jose import jwt, JWTError
from fastapi import HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from core.config import get_settings

settings = get_settings()
security = HTTPBearer()

class User(BaseModel):
    username: str
    user_id: str
    roles: list = []

def create_token_for_user(username: str, user_id: str = None, roles: list = None) -> Dict[str,Any]:
    payload = {"sub": username, "user_id": user_id or username, "roles": roles or []}
    expires = datetime.utcnow() + timedelta(minutes=settings.access_token_expire_minutes)
    payload.update({"exp": expires})
    token = jwt.encode(payload, settings.secret_key.get_secret_value(), algorithm=settings.algorithm)
    return {"access_token": token, "token_type":"bearer", "expires_in": settings.access_token_expire_minutes*60, "username": username, "roles": roles or []}

def verify_token(token: str) -> Dict[str,Any]:
    try:
        payload = jwt.decode(token, settings.secret_key.get_secret_value(), algorithms=[settings.algorithm])
        return payload
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")

def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> User:
    token = credentials.credentials
    payload = verify_token(token)
    return User(username=payload.get("sub"), user_id=payload.get("user_id"), roles=payload.get("roles", []))
