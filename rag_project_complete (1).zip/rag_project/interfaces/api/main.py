from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Depends, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from datetime import datetime
import logging, uuid, asyncio

from core.config import get_settings
from core.engine import ApplicationEngine, ApplicationConfig
from core.embedding_system import EnhancedAsyncEmbeddingSystem
from interfaces.api.security import get_current_user, create_token_for_user, User

settings = get_settings()
logger = logging.getLogger("api.main")
logging.basicConfig(level=getattr(logging, settings.log_level))

try:
    from slowapi import Limiter, _rate_limit_exceeded_handler
    from slowapi.util import get_remote_address
    limiter = Limiter(key_func=get_remote_address)
    HAS_SLOWAPI = True
except Exception:
    limiter = None
    HAS_SLOWAPI = False

class QueryRequest(BaseModel):
    question: str

MAX_PAYLOAD_SIZE = settings.max_file_size_mb * 1024 * 1024 * 2

@asynccontextmanager
async def lifespan(app: FastAPI):
    cfg = settings
    emb_system = EnhancedAsyncEmbeddingSystem(config=cfg)
    await emb_system._initialize()
    app.state.embedding_system = emb_system
    engine_cfg = ApplicationConfig(
        allowed_upload_dir=str(Path(cfg.storage_path) / "uploads"),
        max_file_size_bytes=cfg.max_file_size_mb * 1024 * 1024
    )
    app.state.engine = ApplicationEngine(embedding_system=emb_system, config=engine_cfg)
    try:
        yield
    finally:
        try:
            await app.state.embedding_system.shutdown()
        except Exception:
            pass

app = FastAPI(lifespan=lifespan, title="RAG API")

if HAS_SLOWAPI:
    app.state.limiter = limiter
    app.add_exception_handler(429, _rate_limit_exceeded_handler)

from fastapi.middleware.cors import CORSMiddleware
cors_origins = []
if settings.cors_allowed_origins:
    cors_origins = [o.strip() for o in settings.cors_allowed_origins.split(",") if o.strip()]
if cors_origins:
    app.add_middleware(CORSMiddleware, allow_origins=cors_origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.middleware("http")
async def payload_size_validator(request: Request, call_next):
    cl = request.headers.get("content-length")
    if cl and int(cl) > MAX_PAYLOAD_SIZE:
        return JSONResponse(status_code=413, content={"detail":"Payload too large"})
    return await call_next(request)

@app.get("/health")
async def health():
    return {"status":"ok", "time": datetime.utcnow().isoformat()}

@app.post("/auth/demo_token")
async def demo_token(username: str):
    return create_token_for_user(username=username)

@app.post("/query")
async def query(req: QueryRequest, user: User = Depends(get_current_user)):
    if not hasattr(app.state, "engine"):
        raise HTTPException(status_code=503, detail="Engine not ready")
    if HAS_SLOWAPI:
        await app.state.limiter.limit("10/minute")(lambda: None)()
    res = await app.state.engine.process_query(req.question)
    return res

@app.post("/upload")
async def upload(file: UploadFile = File(...), user: User = Depends(get_current_user)):
    tmp = Path("/tmp") / f"upload_{uuid.uuid4().hex}_{file.filename}"
    content = await file.read()
    tmp.write_bytes(content)
    if tmp.stat().st_size > app.state.engine.config.max_file_size_bytes:
        tmp.unlink(missing_ok=True)
        raise HTTPException(status_code=413, detail="Uploaded file too large")
    res = await app.state.engine.process_upload(str(tmp))
    return res
