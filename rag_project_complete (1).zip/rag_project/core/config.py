from functools import lru_cache
from pathlib import Path
from typing import Optional, Set
from pydantic import SecretStr, Field, conint
from pydantic.networks import HttpUrl
from pydantic_settings import BaseSettings, SettingsConfigDict
import re

class AppSettings(BaseSettings):
    model_embedding: str = Field(..., env="EMBEDDING_MODEL")
    model_chat: str = Field(..., env="CHAT_MODEL")
    ollama_base_url: HttpUrl = Field(default="http://localhost:11434", env="OLLAMA_BASE_URL")
    storage_path: Path = Field(default=Path("./storage").resolve(), env="STORAGE_PATH")
    chroma_persist_directory: Path = Field(default=Path("./chroma_db").resolve(), env="CHROMA_PERSIST_DIRECTORY")
    secret_key: SecretStr = Field(..., env="SECRET_KEY")
    algorithm: str = Field(default="HS256", env="ALGORITHM")
    access_token_expire_minutes: conint(ge=1, le=1440) = Field(default=30, env="ACCESS_TOKEN_EXPIRE_MINUTES")
    max_file_size_mb: conint(ge=1, le=1024) = Field(default=50, env="MAX_FILE_SIZE_MB")
    allowed_extensions: Set[str] = Field(default_factory=lambda: {".pdf", ".txt", ".md", ".docx"}, env="ALLOWED_EXTENSIONS")
    api_host: str = Field(default="127.0.0.1", env="API_HOST")
    api_port: conint(ge=1024, le=65535) = Field(default=8000, env="API_PORT")
    api_reload: bool = Field(default=False, env="API_RELOAD")
    log_level: str = Field(default="INFO", env="LOG_LEVEL")
    cors_allowed_origins: Optional[str] = Field(default=None, env="CORS_ALLOWED_ORIGINS")

    model_config = SettingsConfigDict(env_file=".env.local,.env", extra="forbid")

    def __init__(self, **values):
        super().__init__(**values)
        sk = self.secret_key.get_secret_value()
        if len(sk) < 32:
            raise ValueError("SECRET_KEY must be at least 32 characters")
        classes = 0
        classes += 1 if re.search(r'[a-z]', sk) else 0
        classes += 1 if re.search(r'[A-Z]', sk) else 0
        classes += 1 if re.search(r'\d', sk) else 0
        classes += 1 if re.search(r'[^A-Za-z0-9]', sk) else 0
        if classes < 3:
            raise ValueError("SECRET_KEY must contain at least three character classes (lower, upper, digit, symbol)")

@lru_cache(maxsize=1)
def get_settings() -> AppSettings:
    return AppSettings()
