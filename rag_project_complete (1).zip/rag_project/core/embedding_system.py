"""Enhanced embedding system with ChromaDB integration, Ollama client, caching and storage."""
from __future__ import annotations
import asyncio, hashlib, json, logging, shutil, time, uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Iterable, Tuple

# Optional deps
try:
    import httpx
    HAS_HTTPX = True
except Exception:
    httpx = None
    HAS_HTTPX = False

try:
    import aiosqlite
    HAS_AIOSQLITE = True
except Exception:
    aiosqlite = None
    HAS_AIOSQLITE = False

try:
    import fitz
    HAS_PYMUPDF = True
except Exception:
    fitz = None
    HAS_PYMUPDF = False

try:
    from docx import Document as DocxDocument
    HAS_DOCX = True
except Exception:
    DocxDocument = None
    HAS_DOCX = False

try:
    from pptx import Presentation
    HAS_PPTX = True
except Exception:
    Presentation = None
    HAS_PPTX = False

try:
    import chromadb
    from chromadb.config import Settings as ChromaSettings
    HAS_CHROMADB = True
except Exception:
    chromadb = None
    ChromaSettings = None
    HAS_CHROMADB = False

# dataclass
@dataclass
class DocumentProvenance:
    document_id: str
    content_hash: str
    created_at: str
    source_file: Optional[str] = None
    metadata: Optional[Dict[str,Any]] = None

    def to_dict(self):
        return asdict(self)

# Advanced in-memory LRU+TTL cache
class AdvancedCache:
    def __init__(self, max_size: int = 2048, ttl_seconds: int = 3600):
        self.max_size = int(max_size)
        self.ttl = int(ttl_seconds)
        self.store: Dict[str, Tuple[float, Any]] = {}
        self.order: List[str] = []
        self.lock = asyncio.Lock()
        self.hits = 0
        self.misses = 0

    async def get(self, key: str):
        async with self.lock:
            item = self.store.get(key)
            now = time.time()
            if not item:
                self.misses += 1
                return None
            ts, val = item
            if now - ts > self.ttl:
                # expired
                self._evict(key)
                self.misses += 1
                return None
            # update LRU order
            if key in self.order:
                self.order.remove(key)
            self.order.insert(0, key)
            self.hits += 1
            return val

    async def set(self, key: str, value: Any):
        async with self.lock:
            if key in self.store:
                self.store[key] = (time.time(), value)
                if key in self.order:
                    self.order.remove(key)
                self.order.insert(0, key)
                return
            while len(self.store) >= self.max_size:
                old = self.order.pop()
                self.store.pop(old, None)
            self.store[key] = (time.time(), value)
            self.order.insert(0, key)

    async def stats(self):
        async with self.lock:
            return {"size": len(self.store), "max_size": self.max_size, "ttl": self.ttl, "hits": self.hits, "misses": self.misses}

    def _evict(self, key: str):
        self.store.pop(key, None)
        if key in self.order:
            self.order.remove(key)

# helpers
def chunk_text(text: str, max_tokens: int = 1000) -> List[str]:
    max_chars = max_tokens * 4
    if len(text) <= max_chars:
        return [text]
    parts = []
    start = 0
    while start < len(text):
        end = min(len(text), start + max_chars)
        chunk = text[start:end]
        # try to break at newline for better splits
        nl = text.rfind("\n", start, end)
        if nl > start:
            end = nl+1
            chunk = text[start:end]
        parts.append(chunk)
        start = end
    return parts

# Ollama client
class AsyncOllamaClient:
    def __init__(self, base_url: str = "http://localhost:11434", timeout: float = 60.0, max_retries: int = 3):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._client = None
        self.logger = logging.getLogger("AsyncOllamaClient")
        self._lock = asyncio.Lock()

    async def _ensure(self):
        if not HAS_HTTPX:
            raise RuntimeError("httpx is required")
        if self._client:
            return
        async with self._lock:
            if self._client:
                return
            self._client = httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout)

    async def _request(self, method: str, path: str, **kwargs):
        await self._ensure()
        attempt = 0
        backoff = 0.5
        while True:
            try:
                resp = await self._client.request(method, path, **kwargs)
                resp.raise_for_status()
                return resp
            except Exception as exc:
                attempt += 1
                if attempt > self.max_retries:
                    self.logger.exception("Request failed %s %s", method, path)
                    raise
                await asyncio.sleep(backoff)
                backoff = min(10.0, backoff*2)

    async def generate(self, model: str, prompt: str, max_tokens: int = 512, temperature: float = 0.0, stream: bool = False):
        payload = {"model": model, "prompt": prompt, "max_tokens": int(max_tokens), "temperature": float(temperature)}
        if stream:
            await self._ensure()
            async with self._client.stream("POST", "/api/generate", json=payload, timeout=self.timeout) as resp:
                resp.raise_for_status()
                async for chunk in resp.aiter_text():
                    yield chunk
            return
        resp = await self._request("POST", "/api/generate", json=payload, timeout=self.timeout)
        return resp.json()

    async def embed_texts(self, model: str, texts: List[str]) -> List[List[float]]:
        payload = {"model": model, "texts": texts}
        resp = await self._request("POST", "/api/embed", json=payload, timeout=self.timeout)
        return resp.json()

    async def close(self):
        if self._client:
            await self._client.aclose()
            self._client = None

# Source store
class AsyncSourceStore:
    def __init__(self, storage_path: str, max_workers: int = 4):
        self.path = Path(storage_path).resolve()
        self.files_dir = self.path / "files"
        self.files_dir.mkdir(parents=True, exist_ok=True)
        self.db = (self.path / "source_metadata.db").resolve()
        self._executor = ThreadPoolExecutor(max_workers=int(max_workers))
        self._sem = asyncio.Semaphore(8)
        self.logger = logging.getLogger("AsyncSourceStore")

    async def init_db(self):
        if not HAS_AIOSQLITE:
            raise RuntimeError("aiosqlite required")
        async with self._sem:
            async with aiosqlite.connect(str(self.db)) as conn:
                await conn.executescript("""
                CREATE TABLE IF NOT EXISTS source_files (
                    document_id TEXT PRIMARY KEY,
                    original_filename TEXT,
                    file_type TEXT,
                    file_size INTEGER,
                    content_hash TEXT UNIQUE,
                    stored_path TEXT,
                    created_at TEXT,
                    metadata_json BLOB,
                    access_count INTEGER DEFAULT 0,
                    last_accessed TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_content_hash ON source_files(content_hash);
                CREATE INDEX IF NOT EXISTS idx_file_type ON source_files(file_type);
                CREATE INDEX IF NOT EXISTS idx_created_at ON source_files(created_at);
                CREATE INDEX IF NOT EXISTS idx_access_count ON source_files(access_count);
                """)
                await conn.commit()

    def _hash(self, p: Path) -> str:
        h = hashlib.sha256()
        with open(p, "rb") as fh:
            for chunk in iter(lambda: fh.read(131072), b""):
                h.update(chunk)
        return h.hexdigest()

    async def store_file(self, file_path: str, document_id: Optional[str] = None, metadata: Optional[Dict[str,Any]] = None) -> str:
        await self.init_db()
        p = Path(file_path).resolve()
        if not p.exists():
            raise FileNotFoundError(file_path)
        document_id = document_id or str(uuid.uuid4())
        loop = asyncio.get_event_loop()
        file_hash = await loop.run_in_executor(self._executor, self._hash, p)
        async with aiosqlite.connect(str(self.db)) as conn:
            async with conn.execute("SELECT stored_path FROM source_files WHERE content_hash = ?", (file_hash,)) as cur:
                row = await cur.fetchone()
                if row:
                    return row[0]
        dest = self.files_dir / f"{document_id}{p.suffix}"
        await loop.run_in_executor(self._executor, shutil.copy2, str(p), str(dest))
        now = datetime.now(timezone.utc).isoformat()
        meta_json = json.dumps(metadata or {}, separators=(",", ":")).encode("utf-8")
        async with aiosqlite.connect(str(self.db)) as conn:
            await conn.execute("INSERT INTO source_files(document_id, original_filename, file_type, file_size, content_hash, stored_path, created_at, metadata_json, access_count, last_accessed) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                               (document_id, p.name, p.suffix.lower().lstrip("."), p.stat().st_size, file_hash, str(dest), now, meta_json, 1, now))
            await conn.commit()
        return str(dest)

    async def get_stats(self, page: int = 1, page_size: int = 50):
        await self.init_db()
        offset = max(0, (page-1)*page_size)
        async with aiosqlite.connect(str(self.db)) as conn:
            async with conn.execute("SELECT COUNT(*) FROM source_files") as cur:
                total = (await cur.fetchone())[0]
            async with conn.execute("SELECT document_id, original_filename, file_type, file_size, access_count, last_accessed FROM source_files ORDER BY created_at DESC LIMIT ? OFFSET ?", (page_size, offset)) as cur:
                rows = await cur.fetchall()
                cols = [d[0] for d in cur.description]
                items = [dict(zip(cols, r)) for r in rows]
        return {"total": int(total), "page": page, "page_size": page_size, "items": items}

# Document processor
class AsyncDocumentProcessor:
    def __init__(self, max_workers: int = 4):
        self._pool = ThreadPoolExecutor(max_workers=int(max_workers))
        self.logger = logging.getLogger("AsyncDocumentProcessor")

    async def process_file(self, file_path: str):
        p = Path(file_path).resolve()
        if not p.exists():
            raise FileNotFoundError(file_path)
        ext = p.suffix.lower()
        loop = asyncio.get_event_loop()
        if ext == ".pdf":
            if not HAS_PYMUPDF:
                raise RuntimeError("PyMuPDF required")
            chunks = await loop.run_in_executor(self._pool, self._process_pdf, p)
        elif ext == ".docx":
            if not HAS_DOCX:
                raise RuntimeError("python-docx required")
            chunks = await loop.run_in_executor(self._pool, self._process_docx, p)
        else:
            chunks = await loop.run_in_executor(self._pool, self._process_text, p)
        # chunk to token limit
        out = []
        for c in chunks:
            for i, sub in enumerate(chunk_text(c.get("content",""), max_tokens=1000)):
                entry = dict(c)
                entry["content"] = sub
                entry["chunk_index"] = i
                out.append(entry)
        return out

    def _process_pdf(self, p: Path):
        texts = []
        doc = fitz.open(str(p))
        for i in range(len(doc)):
            page = doc[i]
            txt = page.get_text("text") or ""
            if txt.strip():
                texts.append({"content": txt, "page": i+1})
        doc.close()
        return texts

    def _process_docx(self, p: Path):
        texts = []
        doc = DocxDocument(str(p))
        for i, para in enumerate(doc.paragraphs, start=1):
            t = (para.text or "").strip()
            if t:
                texts.append({"content": t, "paragraph": i})
        return texts

    def _process_text(self, p: Path):
        with open(p, "r", encoding="utf-8", errors="ignore") as fh:
            txt = fh.read()
        paras = [seg.strip() for seg in txt.split("\n\n") if seg.strip()]
        if not paras:
            paras = [txt]
        return [{"content": seg} for seg in paras]

# Main orchestrator
class EnhancedAsyncEmbeddingSystem:
    REQUIRED_CONFIG_KEYS = ["storage_path", "ollama_base_url", "model_embedding", "model_chat"]

    def __init__(self, config: Any):
        self.logger = logging.getLogger("EnhancedAsyncEmbeddingSystem")
        missing = [k for k in self.REQUIRED_CONFIG_KEYS if not getattr(config, k, None)]
        if missing:
            raise ValueError(f"Missing config: {missing}")
        self.config = config
        self.storage_path = Path(getattr(self.config, "storage_path"))
        self.chroma_persist = Path(getattr(self.config, "chroma_persist_directory", self.storage_path / "chroma"))
        self._initialized = False
        self._lock = asyncio.Lock()
        self.ollama = None
        self.store = None
        self.processor = None
        self.embed_cache = AdvancedCache(max_size=4096, ttl_seconds=24*3600)
        self.search_cache = AdvancedCache(max_size=2048, ttl_seconds=600)
        self._chroma_client = None
        self._chroma_collection = None

    async def _initialize(self):
        if self._initialized:
            return
        async with self._lock:
            if self._initialized:
                return
            self.ollama = AsyncOllamaClient(base_url=str(getattr(self.config, "ollama_base_url")))
            self.store = AsyncSourceStore(storage_path=str(self.storage_path / "source_store"), max_workers=8)
            await self.store.init_db()
            self.processor = AsyncDocumentProcessor(max_workers=8)
            if HAS_CHROMADB:
                # init chroma client
                self._chroma_client = chromadb.Client(ChromaSettings(chroma_db_impl="duckdb+parquet", persist_directory=str(self.chroma_persist)))
                coll_name = "enhanced_docs_v1"
                try:
                    self._chroma_collection = self._chroma_client.get_collection(coll_name)
                except Exception:
                    self._chroma_collection = self._chroma_client.create_collection(coll_name)
            self._initialized = True
            self.logger.info("Initialized EnhancedAsyncEmbeddingSystem")

    async def add_documents_to_vector_store(self, documents: Iterable[Dict[str,Any]], batch_size: int = 64, dedup: bool = True):
        if not HAS_CHROMADB or self._chroma_collection is None:
            raise RuntimeError("ChromaDB not available")
        docs = list(documents)
        ids, embs, metas, docs_text = [], [], [], []
        for doc in docs:
            content = doc.get("content","")

            content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
            if dedup:
                # try quick existing check by metadata
                try:
                    existing = self._chroma_collection.get(where={"content_hash": content_hash}, include=["ids"], n_results=1)
                    if existing and existing.get("ids") and existing.get("ids")[0]:
                        continue
                except Exception:
                    pass
            cache_key = f"emb:{content_hash}"
            emb = await self.embed_cache.get(cache_key)
            if emb is None:
                emb = await self.ollama.embed_texts(getattr(self.config, 'model_embedding'), [content])
                if isinstance(emb, list) and emb:
                    emb = emb[0]
                await self.embed_cache.set(cache_key, emb)
            uid = doc.get("id") or str(uuid.uuid4())
            ids.append(uid)
            embs.append(emb)
            metas.append({**(doc.get("metadata") or {}), "content_hash": content_hash})
            docs_text.append(content)
            if len(ids) >= batch_size:
                self._chroma_collection.add(ids=ids, embeddings=embs, metadatas=metas, documents=docs_text)
                ids, embs, metas, docs_text = [], [], [], []
        if ids:
            self._chroma_collection.add(ids=ids, embeddings=embs, metadatas=metas, documents=docs_text)
        try:
            self._chroma_client.persist()
        except Exception:
            pass
        return {"inserted": True}

    async def search_similar_documents(self, query: str, limit: int = 5, threshold: float = 0.2, re_ranking: bool = True, filters: Optional[Dict[str,Any]] = None):
        if not HAS_CHROMADB or self._chroma_collection is None:
            raise RuntimeError("ChromaDB not initialized")
        cache_key = f"search:{hashlib.sha256((query+json.dumps(filters or {})).encode()).hexdigest()}:{limit}:{threshold}"
        cached = await self.search_cache.get(cache_key)
        if cached:
            return cached
        qhash = hashlib.sha256(query.encode()).hexdigest()
        qemb = await self.embed_cache.get(f"q:{qhash}")
        if qemb is None:
            qemb = await self.ollama.embed_texts(getattr(self.config, 'model_embedding'), [query])[0]
            await self.embed_cache.set(f"q:{qhash}", qemb)
        where = filters or {}
        results = self._chroma_collection.query(query_embeddings=[qemb], n_results=limit, where=where, include=["metadatas","documents","distances"])
        hits = []
        ids = results.get("ids", [[]])[0]
        docs = results.get("documents", [[]])[0]
        metas = results.get("metadatas", [[]])[0]
        dists = results.get("distances", [[]])[0]
        for i, _id in enumerate(ids):
            dist = dists[i] if i < len(dists) else 0.0
            score = 1.0 - float(dist) if dist <= 1.0 else float(dist)
            hit = {"id": _id, "score": score, "document": docs[i], "metadata": metas[i]}
            hits.append(hit)
        # thresholding
        hits = [h for h in hits if h["score"] >= threshold]
        # simple rerank by keyword overlap
        if re_ranking:
            q_terms = set(t.lower() for t in query.split() if len(t) > 2)
            for h in hits:
                text = (h.get("document") or "").lower()
                km = sum(1 for t in q_terms if t in text)
                h["score"] = h["score"] + 0.01 * km
            hits.sort(key=lambda x: x["score"], reverse=True)
        await self.search_cache.set(cache_key, hits)
        return hits

    async def shutdown(self):
        if self.ollama:
            try:
                await self.ollama.close()
            except Exception:
                pass
