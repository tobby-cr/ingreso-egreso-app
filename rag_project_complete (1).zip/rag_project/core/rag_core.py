"""RAG core logic: sanitization, retrieval orchestration and LLM invocation with citation checks."""
from __future__ import annotations
import asyncio, logging, re
from typing import Any, Dict, List, Optional

logger = logging.getLogger("rag_core")

_INJECTION_PATTERNS = [r"\{\{.*\}\}", r"<script.*?>", r"ignore previous instructions", r"please respond with only"]

def sanitize_text(text: str, max_len: int = 2000) -> str:
    if not text:
        return ""
    text = text.strip()
    text = "".join(ch for ch in text if ord(ch) >= 32)
    if len(text) > max_len:
        text = text[:max_len]
    lowered = text.lower()
    for p in _INJECTION_PATTERNS:
        if re.search(p, lowered):
            raise ValueError("Potential prompt injection detected")
    return text

async def generate_rag_response(question: str, embedding_system, top_k: int = 5, threshold: float = 0.2, timeout_seconds: float = 30.0, llm_model: Optional[str] = None) -> Dict[str,Any]:
    question = sanitize_text(question, max_len=2000)
    if not question:
        raise ValueError("Empty question")
    try:
        results = await asyncio.wait_for(embedding_system.search_similar_documents(question, limit=top_k, threshold=threshold), timeout=timeout_seconds)
    except asyncio.TimeoutError:
        return {"answer":"","sources":[],"error":"retrieval_timeout"}
    except Exception as e:
        logger.exception("Retrieval failed: %s", e)
        return {"answer":"","sources":[],"error":"retrieval_error"}
    # build context
    context_parts = []
    sources = []
    for r in results:
        doc = r.get("document") or ""
        meta = r.get("metadata") or {}
        src = meta.get("source_file") or meta.get("content_hash") or r.get("id") or "unknown"
        context_parts.append(f"[SOURCE_START]\n{doc}\n[SOURCE_END]\n[SOURCE:{src}]\n")
        sources.append(str(src))
    prompt_header = ("You are an assistant. Use ONLY the following sources to answer and cite them as [SOURCE:id]. If not available, say I don't know." + "\n\n")
    prompt = prompt_header + "\n\n".join(context_parts) + "\nQuestion:\n" + question + "\nAnswer:\n"
    llm_model = llm_model or getattr(embedding_system.config, 'model_chat', None)
    if not getattr(embedding_system, 'ollama', None):
        return {"answer":"","sources":[],"error":"llm_not_ready"}
    try:
        resp = await asyncio.wait_for(embedding_system.ollama.generate(model=llm_model, prompt=prompt, max_tokens=512, temperature=0.0, stream=False), timeout=timeout_seconds)
    except asyncio.TimeoutError:
        return {"answer":"","sources":[],"error":"llm_timeout"}
    except Exception as e:
        logger.exception("LLM error: %s", e)
        return {"answer":"","sources":[],"error":"llm_error"}
    # parse
    if isinstance(resp, dict):
        out = resp.get("output") or resp.get("text") or resp.get("answer") or str(resp)
    else:
        out = str(resp)
    cited = re.findall(r"\[SOURCE:([^\]]+)\]", out)
    verified = [c for c in cited if any(c in s for s in sources)]
    return {"answer": out, "sources": verified}
