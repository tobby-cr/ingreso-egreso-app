print('Run: streamlit run interfaces/web/app.py')
